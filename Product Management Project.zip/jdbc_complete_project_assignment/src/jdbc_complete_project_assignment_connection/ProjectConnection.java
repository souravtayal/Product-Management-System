package jdbc_complete_project_assignment_connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ProjectConnection {

	
	public static Connection getAdminConnection()
	{
			try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//but this is used if we want to store
			//Connection connection  = DriverManager.getConnection("jdbc:mysql://localhost:3306:jdbc-a3","root","root");
			//return connection
			
			 return DriverManager.getConnection("jdbc:mysql://localhost:3306/servlet_a3","root","root");
			
			
		} catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
			return null;
		}
	}
}
