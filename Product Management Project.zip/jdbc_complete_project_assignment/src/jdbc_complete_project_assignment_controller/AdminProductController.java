package jdbc_complete_project_assignment_controller;

import java.time.LocalDate;
import java.util.Scanner;

import jdbc_complete_project_assignment_dao.AdminDao;
import jdbc_complete_project_assignment_dao.CustomerRegisterDao;
import jdbc_complete_project_assignment_dao.ProductDetailsDao;
import jdbc_complete_project_assignment_dao.ProductOwnerRegisterDao;
import jdbc_complete_project_assignment_dto.Admin;
import jdbc_complete_project_assignment_dto.CustomerRegister;
import jdbc_complete_project_assignment_dto.Product;
import jdbc_complete_project_assignment_dto.ProductOwnerRegister;
import jdbc_complete_project_assignment_service.AdminLoginService;
import jdbc_complete_project_assignment_service.CustomerRegistrationService;
import jdbc_complete_project_assignment_service.CustomerService;
import jdbc_complete_project_assignment_service.ProductOwnerRegistrationService;
import jdbc_complete_project_assignment_service.ProductOwnerService;

public class AdminProductController {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		AdminDao aDao = new AdminDao();
		ProductOwnerRegisterDao psDao = new ProductOwnerRegisterDao();
		CustomerRegisterDao crDao = new CustomerRegisterDao();
		AdminLoginService service=new AdminLoginService();
		ProductDetailsDao pdd = new ProductDetailsDao();
		ProductOwnerService pos = new ProductOwnerService();
		
		CustomerRegistrationService crservice = new CustomerRegistrationService();
		ProductOwnerRegistrationService pors  = new ProductOwnerRegistrationService();
		while(true)
		{
		System.out.println("Press 1 for Admin Login");
		System.out.println("Press 2 for Product Owner Login");
		System.out.println("Press 3 for Product Owner Register");
		System.out.println("Press 4 for Customer Login");
		System.out.println("Press 5 for Customer Register");
		
		
		int option=sc.nextInt();
		
		switch(option)
		{
		case 1:{
				
				System.out.println("Enter the email");
				sc.nextLine();
				String email=sc.next();
				System.out.println("Enter the password");
				String password=sc.next();
				
				
				Admin admin = aDao.fetchAdminDetailByEmail(email);
					
				if(admin!=null)
				{
					if(admin.getPassword().equals(password))
					{
						System.out.println("Admin Login Success");
					}
					else {
						System.out.println("Password is wrong");
					}
				}
				else {
					System.out.println("Email Verfication Failed");
				}
				
				
		}break;
        case 2:{
        	System.out.println("Enter the email");
        	String ownerEmail = sc.next();
        	System.out.println("Enter the password");
        	String ownerPassword=sc.next();
        	
        	ProductOwnerRegister  ps = psDao.loginOwnerByEmail(ownerEmail);
        	
        	
        	if(ps!=null)
        	{
        		if(ps.getPassword().equals(ownerPassword))
        		{
        			System.out.println("Login Sucess");
        			while(true)
        			{
        			System.out.println("Select 1 for add Product");
        			System.out.println("Select 2 for update Product");
        			System.out.println("Select 3 for delete Product");
        			System.out.println("Select 4 for display products");
        			int optionC = sc.nextInt();
        			switch(optionC)
        			{
        			case 1:{
        				    System.out.println("Enter the id");
        				    int id=sc.nextInt();
        				    sc.nextLine();
        				    System.out.println("Enter the name");
        				    String name=sc.nextLine();
        				    System.out.println("Enter the price");
        				    long price =sc.nextLong();
        				    sc.nextLine();
        				    System.out.println("ENter the color");
        				    String color=sc.next();
        				    System.out.println("Enter the modification date");
        				    String mfg = sc.next();
        				    System.out.println("ENter the expiry Date");
        				    String exp=sc.next();
        				    
        				    Product product = new Product(id,name,price,color,LocalDate.parse(mfg),LocalDate.parse(exp));
        				    
        				    Product product2 = pos.saveProductService(product);
        				    
        				    if(product!=null)
        				    {
        				    	System.out.println("Product is added Successfully");
        				    }
        				    else {
        				    	System.out.println("Product is not added");
        				    }
        			}break;
        			
        			case 2:{
        				System.out.println("ENter product id to change the details");
        				int id=sc.nextInt();
        				
        				System.out.println("Enter option 1 to change name");
        				System.out.println("Enter option 2 to change price");
        				System.out.println("Enter option 3 to change color");
        				System.out.println("Enter option 4 to change mfg");
        				System.out.println("Enter option 5 to change exp");
        				int option3=sc.nextInt();
        				sc.nextLine();
        				switch(option3)
        				{
        				
        				
        				case 1:{
        					System.out.println("ENter the new name");
        					String name=sc.nextLine();
        					Product product = new Product(id,name);
        					int value=pdd.updateProductByName(id, name);
        					if(value==1)
        					{
        						System.out.println("Name is updated");
        					}
        					else {
        						System.out.println("Name is not updated");
        					}
        				}break;
        				case 2:{
        					System.out.println("ENter the new price");
        					Long price=sc.nextLong();
        					Product product = new Product(id,price);
        					int value=pdd.updateProductByPrice(id, price);
        					if(value==1)
        					{
        						System.out.println("Price is updated");
        					}
        					else {
        						System.out.println("Price is not updated");
        					}
        				}break;
        				case 3:
        				{
        					System.out.println("ENter the new color");
        					String color=sc.nextLine();
        					Product product = new Product(id,color);
        					int value=pdd.updateProductByName(id, color);
        					if(value==1)
        					{
        						System.out.println("Color is updated");
        					}
        					else {
        						System.out.println("Color is not updated");
        					}
        					
        				}break;
        				case 4:{
        					System.out.println("ENter the new mfg");
        					String mfg=sc.nextLine();
        					Product product = new Product(id,mfg);
        					int value=pdd.updateProductByName(id, mfg);
        					if(value==1)
        					{
        						System.out.println("Mfg is updated");
        					}
        					else {
        						System.out.println("Mfg is not updated");
        					}
        					
        				}break;
        				case 5:{
        					System.out.println("ENter the new exp");
        					String exp=sc.nextLine();
        					Product product = new Product(id,exp);
        					int value=pdd.updateProductByName(id, exp);
        					if(value==1)
        					{
        						System.out.println("Exp is updated");
        					}
        					else {
        						System.out.println("Exp is not updated");
        					}
        					
        				}break;
        				}
        				
        				
        			}break;
        			
        			case 3:{
        				System.out.println("Enter product id to delete");
        				int id=sc.nextInt();
        				int value= pdd.deleteProductByIdDao(id);
        				
        				if(value==1)
        				{
        					System.out.println("Product deleted successfully");
        				}
        				else {
        					System.out.println("Product not deleted");
        				}
        				
        			}break;
        			case 4:{
        				Product[] product = pos.displayProductsDao();
        				for(Product productD:product)
        				{

        						if(productD!=null)
        						{
        							System.out.println(productD);
        						}
        				}
        			}break;
        				
        			}
        		}
        		}
        		else {
        			System.out.println("Password is wrong try again");
        		}
        		
        	}
        	else {
        		System.out.println("Email is wrong");
        	}
        	}break;
        	
        case 3:{
        	System.out.println("Enter the id");
        	int id=sc.nextInt();
        	sc.nextLine();
        	System.out.println("Enter the name");
        	String name=sc.nextLine();
        	System.out.println("Enter the email");
        	String email=sc.nextLine();
        	System.out.println("Enter the password");
        	String password=sc.nextLine();
        	
        	ProductOwnerRegister ps = new ProductOwnerRegister(id,name,email,password,"yes");
        	
        	ProductOwnerRegister ps2 = pors.saveOwnerDetailsService(ps) ;
        	
        	if(ps2!=null)
        	{
        		System.out.println("You are registered");
        	}
        	else {
        		System.out.println("You are not registered");
        	}
        	
        	
        	
        	
        	
        	
	
        }break;
        case 4:{
        		sc.nextLine();
        		System.out.println("Enter the email");
        		String email=sc.next();
        		System.out.println("Enter the password");
        		String password=sc.next();
        		
        		CustomerRegister cs = crDao.customerLoginByEmailDao(email);
        		
        		
        		if(cs!=null)
        		{
        			if(cs.getPassword().equals(password))
            		{
        			System.out.println("Customer Login Successfully");
        			
        			System.out.println("AVAILABLE PRODUCTS ARE");
        			Product[] product = pos.displayProductsDao();
    				for(Product productD:product)
    				{

    						if(productD!=null)
    						{
    							System.out.println(productD);
    						}
    				}
            		
            		
            		}
        			else {
        				System.out.println("Password is wrong try again");
        			
        			}
        		}
        		else {
        			System.out.println("Customer Login Failed");
        		}
        	}break;
        case 5:{
        		System.out.println("Enter the id");
        		int id=sc.nextInt();
        		sc.nextLine();
        		System.out.println("Enter the name");
        		String name=sc.nextLine();
        		System.out.println("Enter the email");
        		String email=sc.next();
        		System.out.println("Enter the password");
        		String password = sc.next();
        		
        		CustomerRegister  cs = new CustomerRegister(id,name,email,password);
        		
        		CustomerRegister cs2 = crservice.saveCustomer(cs);
        		
        		if(cs2!=null)
        		{
        			System.out.println("You are registered Successfully");
        			
        		}
        		else {
        			System.out.println("You are not registered try again");
        		}
        }break;
        
	  }
	}
}
}

        	
     


