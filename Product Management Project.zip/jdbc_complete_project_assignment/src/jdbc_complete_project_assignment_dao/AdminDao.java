package jdbc_complete_project_assignment_dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jdbc_complete_project_assignment_connection.ProjectConnection;
import jdbc_complete_project_assignment_dto.Admin;

public class AdminDao {

	PreparedStatement ps;
	
	Connection connection = ProjectConnection.getAdminConnection();
	
	private final String QUERYFORLOGINADMIN = "select email,password from admin where email=?";
	
	public Admin fetchAdminDetailByEmail(String email)
	{
		Admin admin=null;
		
		
		try {
			ps = connection.prepareStatement(QUERYFORLOGINADMIN);
			
			ps.setString(1, email);
			
			ResultSet rs= ps.executeQuery();
			
			if(rs.next())
			{
				String emailAd = rs.getString("email");
				String passwordAd = rs.getString("password");
				
				return   new Admin(emailAd,passwordAd);
				 
			}
			return admin;
			
		} catch (SQLException e) {
			
			e.printStackTrace();
			System.out.println("Verification Failed");
			return  null;
		}
 				
	}
}
