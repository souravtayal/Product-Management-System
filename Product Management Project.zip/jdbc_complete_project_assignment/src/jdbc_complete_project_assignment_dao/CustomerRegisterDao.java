package jdbc_complete_project_assignment_dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jdbc_complete_project_assignment_connection.ProjectConnection;
import jdbc_complete_project_assignment_dto.CustomerRegister;

public class CustomerRegisterDao {
	
	Connection connection = ProjectConnection.getAdminConnection();
	
	PreparedStatement ps;
	
	private final String INSERTCUSTOMERQUERY = "insert into customer (id,name,email,password) values(?,?,?,?)";

	private final String customerLoginByEmailDao = "select email,password from customer where email = ? ";
	
	
	
	public CustomerRegister saveCustomerDao(CustomerRegister customer)
	{
		try {
			ps = connection.prepareStatement(INSERTCUSTOMERQUERY);
			
			ps.setInt(1, customer.getId());
			ps.setString(2, customer.getName());
			ps.setString(3, customer.getEmail());
			ps.setString(4, customer.getPassword());
			
			ps.execute();
			
			return customer;
			
		} catch (SQLException e) {
			
			e.printStackTrace();
			return null;
		}
		
		
	}
	
	
	public CustomerRegister customerLoginByEmailDao(String email)
	{
		
		
	  	
	  	try {
			
	  	ps = connection.prepareStatement(customerLoginByEmailDao);
		
	  	ps.setString(1, email);
		
		
		ResultSet rs  = ps.executeQuery();
		
		rs.next();
		String emailC  = rs.getString("email");
		String passwordC= rs.getString("password");
		
		return new CustomerRegister(emailC,passwordC);
			
		
		
		
	  	} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	  	    return null; 
	  	}
	}
	

}
