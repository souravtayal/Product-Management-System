package jdbc_complete_project_assignment_dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import jdbc_complete_project_assignment_connection.ProjectConnection;
import jdbc_complete_project_assignment_dto.Product;
import jdbc_complete_project_assignment_dto.ProductOwnerRegister;

public class ProductDetailsDao {
	
	Connection connection = ProjectConnection.getAdminConnection();
	
	PreparedStatement ps;
	
	private final String  INSERTPRODUCTQUERY = 
			"insert into product (id,name,price,color,mfg,exp) values(?,?,?,?,?,?)";

	private final String DISPLAYPRODUCTQUERY = "select * from product";
	
	private final String DELETE_STUDENT_BY_ID  = "delete from product where id=?";
	
	
	private final String UPDATE_PRODUCT_BY_NAME = "update product set name=? where id=?";
	private final String UPDATE_PRODUCT_BY_PRICE = "update product set price=? where id=?";
	private final String UPDATE_PRODUCT_BY_COLOR = "update product set color=? where id=?";
	private final String UPDATE_PRODUCT_BY_MFG = "update product set mfg=? where id=?";
	private final String UPDATE_PRODUCT_BY_EXP = "update product set exp=? where id=?";
	
	public Product saveProductDao(Product product)
	{
			try {
			
				ps.setInt(1, product.getId());
				ps.setString(2, product.getName());
				ps.setLong(3, product.getPrice());
				ps.setString(4, product.getColor());
				ps.setObject(5, product.getMfg());
				ps.setObject(6, product.getExp());
				ps.execute();
				return product;
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			}
			
		
		
	}
	
	public Product[] displayProductsDao()
	{
		try {
			ps  = connection.prepareStatement(DISPLAYPRODUCTQUERY);
		
			ResultSet rs = ps.executeQuery();
			
			Product[] product = new Product[20];
			
			int i=0;
			while(rs.next())
			{
				int id = rs.getInt("id");
				String name=rs.getString("name");
				Long price=rs.getLong("price");
				String color=rs.getString("color");
				LocalDate mfg = rs.getDate("mfg").toLocalDate();
				LocalDate exp = rs.getDate("exp").toLocalDate();
				
				Product productD = new Product(id, name, price, color,mfg,exp);
				product[i]=productD;
				
				i++;
			}
			return product;
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
	
	}
	
	public int deleteProductByIdDao(int id)
	{
		try {
			ps = connection.prepareStatement(DELETE_STUDENT_BY_ID);
			ps.setInt(1, id);
			return ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
		
	}
	
	
//	public int updateProductById(int id,int id2)
//	{
//		try {
//			ps = connection.prepareStatement(UPDATE_PRODUCT_BY_ID);
//			ps.setInt(1, id);
//			ps.setInt(2, id2);
//			return ps.executeUpdate();
//		
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//			return 0;
//		}
//	}
	public int updateProductByName(int id,String name)
	{
		try {
			ps = connection.prepareStatement(UPDATE_PRODUCT_BY_NAME);
			ps.setInt(1, id);
			ps.setString(2, name);
			return ps.executeUpdate();
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
	
	public int updateProductByPrice(int id,Long price)
	{
		try {
			ps = connection.prepareStatement(UPDATE_PRODUCT_BY_PRICE);
			ps.setInt(1, id);
			ps.setLong(2, price);
			return ps.executeUpdate();
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
	public int updateProductByColor(int id,String color)
	{
		try {
			ps = connection.prepareStatement(UPDATE_PRODUCT_BY_COLOR);
			ps.setInt(1, id);
			ps.setString(2, color);
			return ps.executeUpdate();
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
	public int updateProductByMfg(int id,Date mfg)
	{
		try {
			ps = connection.prepareStatement(UPDATE_PRODUCT_BY_MFG);
			ps.setInt(1, id);
			ps.setObject(2, mfg);
			return ps.executeUpdate();
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
	
	public int updateProductByExp(int id,Date exp)
	{
		try {
			ps = connection.prepareStatement(UPDATE_PRODUCT_BY_EXP);
			ps.setInt(1, id);
			ps.setObject(2, exp);
			return ps.executeUpdate();
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
	
	
}
