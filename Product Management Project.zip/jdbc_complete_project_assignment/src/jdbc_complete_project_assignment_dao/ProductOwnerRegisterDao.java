package jdbc_complete_project_assignment_dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jdbc_complete_project_assignment_connection.ProjectConnection;
import jdbc_complete_project_assignment_dto.ProductOwnerRegister;

public class ProductOwnerRegisterDao {

	Connection connection = ProjectConnection.getAdminConnection();
	
	PreparedStatement ps;
	
	private final String INSERTOWNERQUERY = "insert into productowner (id,name,email,password,verify) values(?,?,?,?,?)";
	
	
	private final String  SELECT_OWNER_BY_EMAIL  = "select email,password from productowner where email = ?";
	
	
	
	public ProductOwnerRegister saveProductOwnerdetails(ProductOwnerRegister pros)
	{
		
		
		try {
			ps = connection.prepareStatement(INSERTOWNERQUERY);
			
			ps.setInt(1,pros.getId());
			ps.setString(2,pros.getName());
			ps.setString(3,pros.getEmail());
			ps.setString(4, pros.getPassword());
			ps.setString(5, pros.getVerify());
			
			ps.execute();
			
			return pros;
		}
         catch (SQLException e) {
			
			e.printStackTrace();
			return null;
		}
	}
	
	public ProductOwnerRegister loginOwnerByEmail(String email)
	{
		
		
		try {
			ps = connection.prepareStatement(SELECT_OWNER_BY_EMAIL);
			ps.setString(1, email);
			
			
			ResultSet rs = ps.executeQuery();
			
			rs.next();
			
			String emailO = rs.getString("email");
			String passwordO= rs.getString("password");
			
			return new ProductOwnerRegister(emailO,passwordO);
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	
	}
	
	
}
