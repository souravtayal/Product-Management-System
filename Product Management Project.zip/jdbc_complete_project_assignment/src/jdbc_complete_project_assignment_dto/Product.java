package jdbc_complete_project_assignment_dto;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;

public class Product implements Serializable {

	private int id;
	private String name;
	private Long price;
	private String color;
	private LocalDate mfg;
	private LocalDate exp;
	
	public Product() {
		super();
	}

	public Product(int id, String name, long price, String color, LocalDate mfg, LocalDate exp) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.color = color;
		this.mfg = mfg;
		this.exp = exp;
	}

	
	
	public Product(int id) {
		super();
		this.id = id;
	}

	
	public Product(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
	

	public Product(int id, LocalDate exp) {
		super();
		this.id = id;
		this.exp = exp;
	}

	public Product( LocalDate mfg,int id) {
		super();
		this.id = id;
		this.mfg = mfg;
	}

	public Product( String color,int id) {
		super();
		this.id = id;
		this.color = color;
	}

	public Product(int id, Long price) {
		super();
		this.id = id;
		this.price = price;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getPrice() {
		return price;
	}

	public void setPrice(Long price) {
		this.price = price;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public LocalDate getMfg() {
		return mfg;
	}

	public void setMfg(LocalDate mfg) {
		this.mfg = mfg;
	}

	public LocalDate getExp() {
		return exp;
	}

	public void setExp(LocalDate exp) {
		this.exp = exp;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price + ", color=" + color + ", mfg=" + mfg
				+ ", exp=" + exp + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(color, exp, id, mfg, name, price);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		return Objects.equals(color, other.color) && Objects.equals(exp, other.exp) && id == other.id
				&& Objects.equals(mfg, other.mfg) && Objects.equals(name, other.name)
				&& Objects.equals(price, other.price);
	}
	
	
	
	
	
	
}
