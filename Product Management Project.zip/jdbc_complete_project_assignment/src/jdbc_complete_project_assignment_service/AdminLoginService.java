package jdbc_complete_project_assignment_service;

import jdbc_complete_project_assignment_dao.AdminDao;
import jdbc_complete_project_assignment_dto.Admin;

public class AdminLoginService {

	
	AdminDao adminDao ;
	
	public boolean checkAdminDetails(String email,String password)
	{
		Admin admin = adminDao.fetchAdminDetailByEmail(email);
		
		System.out.println(admin);
		if(admin!=null&&admin.getPassword().equals(password))
		{
			System.out.println("Login Success");
			return true;
		}
		
		return false;
	}
}
