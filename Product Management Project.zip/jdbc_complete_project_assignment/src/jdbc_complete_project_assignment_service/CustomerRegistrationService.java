package jdbc_complete_project_assignment_service;

import jdbc_complete_project_assignment_dao.CustomerRegisterDao;
import jdbc_complete_project_assignment_dto.CustomerRegister;

public class CustomerRegistrationService {

CustomerRegisterDao csDao = new CustomerRegisterDao();
	
	public CustomerRegister saveCustomer(CustomerRegister customer)
	{
		if(customer.getName().length()<=8)
		{
			return csDao.saveCustomerDao(customer);
			
		}
		else {
			return null;
		}
		
	}
	
	
	
}
