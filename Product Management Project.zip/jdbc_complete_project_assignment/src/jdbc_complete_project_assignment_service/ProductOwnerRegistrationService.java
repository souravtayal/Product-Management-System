package jdbc_complete_project_assignment_service;

import jdbc_complete_project_assignment_dao.ProductOwnerRegisterDao;
import jdbc_complete_project_assignment_dto.ProductOwnerRegister;

public class ProductOwnerRegistrationService {

		ProductOwnerRegisterDao dao = new ProductOwnerRegisterDao();
	
	public ProductOwnerRegister saveOwnerDetailsService(ProductOwnerRegister pors)
	{
		if(pors.getEmail().length()<=20)
		{
//			ProductOwnerRegister por= new ProductOwnerRegister("yes");
			
			return  dao.saveProductOwnerdetails(pors);
		}
		else {
			return null;
		}
	}
	
}
