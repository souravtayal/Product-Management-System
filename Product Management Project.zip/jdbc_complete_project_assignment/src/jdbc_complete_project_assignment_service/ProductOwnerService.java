package jdbc_complete_project_assignment_service;

import jdbc_complete_project_assignment_dao.ProductDetailsDao;
import jdbc_complete_project_assignment_dto.Product;

public class ProductOwnerService {

	ProductDetailsDao pDao  = new ProductDetailsDao();
	
	public Product saveProductService(Product product)
	{
	
			return pDao.saveProductDao(product);
	}
	
	
	public Product[] displayProductsDao()
	{
		Product[] product = pDao.displayProductsDao();
		
		Product[] product2 = new Product[product.length];
		
		for(int i=0;i<product2.length;i++) 
		{
			if(product2!=null)
			{
				product2[i]=product[i];
			}
			
		}
		return product2;
	}
	
	
}
